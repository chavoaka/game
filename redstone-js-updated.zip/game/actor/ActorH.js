export const MAX_ACTOR = 2048;

export const AK_PLAYER = 0;
export const AK_NPC = 1;
export const AK_MONSTER = 2;