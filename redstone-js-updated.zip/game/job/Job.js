
export class JobInfo {
    constructor() {

    }
}

export const JobManager = new class JobManager {
    /**
     * @type {JobInfo[]}
     */
    jobs = [];

    characterDataCount = 0;
    jobList = []; // WORD[]
    
    
}