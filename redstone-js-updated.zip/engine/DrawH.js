export const PUT_SOFT_DODGE = 0;
export const PUT_DIFFERENT = 1;
export const PUT_DODGE_BURN = 2;
export const PUT_SOFT = 3;
export const PUT_DODGE = 4;
export const PUT_LIGHT = 5;
export const PUT_EXTREAM_LIGHT = 6;
export const PUT_NORMAL = 7;
export const PUT_HALF_BLENDING = 8;
export const PUT_COLOR = 9;
export const PUT_ALPHA_BLENDING = 10;
export const PUT_FLIP = 11;

export const SPRITE_BPP16 = 0;
export const SPRITE_FLIP = 11;
export const SPRITE_ZOOM = 22;
export const SPRITE_BPP8 = 44;